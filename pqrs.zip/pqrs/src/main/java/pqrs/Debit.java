package pqrs;

public class Debit implements payment {


	
	public Debit () {
		System.out.println("this is Debit method");
		
	}
	public void pay() {
		// TODO Auto-generated method stub
		System.out.println("hiiii");
	}

}
