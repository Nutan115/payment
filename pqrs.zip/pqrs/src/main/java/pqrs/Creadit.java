package pqrs;

public class Creadit implements payment {
	public Creadit () {
		System.out.println("this is creadit method");
	}

	
	public void pay() {
		// TODO Auto-generated method stub
		System.out.println("hiiii");
	}
	

}
