package pqrs;

public interface payment {

	void pay();
}
